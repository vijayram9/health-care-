package com.example.healthcare.exception;

public class DiagnosticTestNotFoundException extends Exception{
    public DiagnosticTestNotFoundException(String message){
        super(message);
    }
}
