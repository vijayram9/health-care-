package com.example.healthcare.exception;

public class DiagnosticCenterNotFoundException extends Exception {
    public DiagnosticCenterNotFoundException(String message) {
        super(message);
    }
}
