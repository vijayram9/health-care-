package com.example.healthcare;

public enum Status {
    SUCCESS,
    USER_ALREADY_EXISTS,
    FAILURE
}
