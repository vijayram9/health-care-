package com.example.healthcare.controller;
import com.example.healthcare.dao.UserRepository;
import com.example.healthcare.entities.User;
//import com.example.healthcare.service.PatientService;
import com.example.healthcare.service.UserServiceImpl;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import javax.validation.Valid;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("User")
public class UserController {
    private static final Logger roles = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserServiceImpl userService;
    @Autowired
    UserRepository userRepository;

    @ApiOperation("Add a new  User")
    @PostMapping("/register")
    public User regsiterUser(@Valid @RequestBody User user) throws Exception{

        User local=this.userRepository.findByUsername(user.getUsername());

        if(local!=null)
        {
            throw new Exception("user already present");
        }
        else {
            local = this.userRepository.save(user);

            local = this.userRepository.save(user);
        }
        return local;
    }


    @PostMapping("/login")
    public ResponseEntity<List<User>> loginUser(@Valid @RequestBody User user) {
        List<User> users = userRepository.findAll();
        for (User other : users) {
            log.info(String.valueOf(other));
            String name=other.getUsername();
            String pass= other.getPassword();
            if (name.equals(user.getUsername()) && pass.equals(user.getPassword())) {
                ResponseEntity<List<User>> listResponseEntity = new ResponseEntity<>(users, HttpStatus.ACCEPTED);
                return listResponseEntity;
            }
        }
        return new ResponseEntity<>(users, HttpStatus.FORBIDDEN);
    }

    @GetMapping("/getall")
    public ResponseEntity<List<User>> getAllUser()
    {
        return ResponseEntity.ok(this.userService.getAllUser());

    }

    @DeleteMapping("/remove")
    public ResponseEntity<User> removeUser(@RequestBody User user) {
        User userRemoved = userService.removeUser(user);
        if (userRemoved != null)
            return new ResponseEntity<>(user, HttpStatus.ACCEPTED);
        else
            return new ResponseEntity<>(user, HttpStatus.FORBIDDEN);
    }
}
